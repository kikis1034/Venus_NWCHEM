/*
 $Id: rappe.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _RAPPE_H_
#define _RAPPE_H_
/* rappe.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Rappe();
void	solve_Rappe();

#endif
