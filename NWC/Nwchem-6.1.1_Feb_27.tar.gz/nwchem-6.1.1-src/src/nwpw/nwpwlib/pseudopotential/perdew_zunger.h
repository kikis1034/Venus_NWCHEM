/*
 $Id: perdew_zunger.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _PERDEW_ZUNGER_H_
#define _PERDEW_ZUNGER_H_

extern void   R_Perdew_Zunger();
#endif
