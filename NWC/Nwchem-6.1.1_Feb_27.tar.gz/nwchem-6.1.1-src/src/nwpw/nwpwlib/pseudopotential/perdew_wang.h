#ifndef _PERDEW_WANG_H_
#define _PERDEW_WANG_H_

extern void   R_Perdew_Wang();
#endif
/* $Id: perdew_wang.h 21176 2011-10-10 06:35:49Z d3y133 $ */
