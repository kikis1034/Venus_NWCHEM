#ifndef _revPBE96_H_
#define _revPBE96_H_

extern void   R_revPBE_Correlation();
#endif
/* $Id: revpbe_correlation.h 21176 2011-10-10 06:35:49Z d3y133 $ */
