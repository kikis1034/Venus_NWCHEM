#ifndef _VANDERBILT_H_
#define _VANDERBILT_H_
/* vanderbilt.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Vanderbilt();
void	solve_Vanderbilt();

#endif
/* $Id: vanderbilt.h 21176 2011-10-10 06:35:49Z d3y133 $ */
