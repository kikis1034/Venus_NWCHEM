/*
 $Id: name.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef	_NAME_H_
#define _NAME_H_

extern	char * spd_Name(int);

#endif
