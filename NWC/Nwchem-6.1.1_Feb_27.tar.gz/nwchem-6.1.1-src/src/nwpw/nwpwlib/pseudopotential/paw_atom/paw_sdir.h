#ifndef _PAW_SDIR_H_
#define _PAW_SDIR_H_
/*
   $Id: paw_sdir.h 19707 2010-10-29 17:59:36Z d3y133 $
*/


extern void  paw_set_debug(int debug);
extern void  paw_set_sdir(char *sdir, int m9);
extern char* paw_sdir();
extern int   paw_debug();

#endif

