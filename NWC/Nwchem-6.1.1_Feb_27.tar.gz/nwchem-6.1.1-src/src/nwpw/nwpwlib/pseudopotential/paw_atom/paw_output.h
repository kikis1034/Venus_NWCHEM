#ifndef	_PAW_OUTPUT_H_
#define _PAW_OUTPUT_H_

/*
   $Id: paw_output.h 19707 2010-10-29 17:59:36Z d3y133 $
*/


extern void paw_generate_basis_file();

#endif


