#ifndef  _PAW_ERROR_FUNCTION_H_
#define _PAW_ERROR_FUNCTION_H_
/*
   $Id: paw_error_function.h 19707 2010-10-29 17:59:36Z d3y133 $
*/


extern double  paw_my_erf(double x);

#endif

