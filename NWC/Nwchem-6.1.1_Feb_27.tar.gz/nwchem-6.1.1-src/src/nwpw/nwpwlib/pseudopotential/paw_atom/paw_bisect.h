#ifndef _PAW_BYSECT_H_
#define _PAW_BYSECT_H_

/*
   $Id: paw_bisect.h 19707 2010-10-29 17:59:36Z d3y133 $
*/

extern double paw_bisection(double (*my_func)(double), double , double , double );

#endif

