#ifndef	_PAW_GET_INVERSE_H_
#define _PAW_GET_INVERSE_H_
/*
   $Id: paw_get_inverse.h 19707 2010-10-29 17:59:36Z d3y133 $
*/


extern void    paw_get_inverse(double **a, int matrix_size);
extern void paw_test_matrix_inverse();

#endif
