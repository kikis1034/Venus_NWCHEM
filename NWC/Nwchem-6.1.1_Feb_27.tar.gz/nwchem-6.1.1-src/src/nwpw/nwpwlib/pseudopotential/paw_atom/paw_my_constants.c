
/*
   $Id: paw_my_constants.c 19707 2010-10-29 17:59:36Z d3y133 $
*/

void paw_my_constants()
{
}
