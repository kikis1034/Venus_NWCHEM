/*
 $Id: gaussj.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _GAUSSJ_H_
#define _GAUSSJ_H_


extern	void gaussj(int, double*, int, double*);

#endif
