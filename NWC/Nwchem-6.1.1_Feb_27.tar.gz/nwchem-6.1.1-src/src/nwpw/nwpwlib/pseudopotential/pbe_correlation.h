#ifndef _PBE96_H_
#define _PBE96_H_

extern void   R_PBE96_Correlation();
#endif
/* $Id: pbe_correlation.h 21176 2011-10-10 06:35:49Z d3y133 $ */
