#ifndef _Becke_EXCHANGE_H_
#define _Becke_EXCHANGE_H_

extern void   R_Becke_Exchange();
#endif
/* $Id: becke_exchange.h 21176 2011-10-10 06:35:49Z d3y133 $ */
