/*
 $Id: vosko.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _VOSKO_H_
#define _VOSKO_H_

extern void   R_Vosko();
#endif
