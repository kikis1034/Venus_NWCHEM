/*
 $Id: grids.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _GRID_H_
#define _GRID_H_
/* grid.h
   author - Eric Bylaska
*/

extern	void	init_Grids();
extern	double	*alloc_Grid();
extern	void	dealloc_Grid(double*);

#endif
