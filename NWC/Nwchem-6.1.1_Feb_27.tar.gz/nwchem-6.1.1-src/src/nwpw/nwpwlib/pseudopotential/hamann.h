/*
 $Id: hamann.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _HAMANN_H_
#define _HAMANN_H_
/* hamann.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Hamann();
void	solve_Hamann();

#endif
