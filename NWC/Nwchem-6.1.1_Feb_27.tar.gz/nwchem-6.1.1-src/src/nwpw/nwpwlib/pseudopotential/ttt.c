/*
 $Id: ttt.c 19707 2010-10-29 17:59:36Z d3y133 $
*/

#include	<stdio.h>
#include	<math.h>

main()
{
   printf("%le\n",1.0/720.0);
}
