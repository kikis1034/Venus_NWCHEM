#ifndef _SEMICORE_H_
#define _SEMICORE_H_

extern void   generate_rho_semicore();
#endif
/* $Id: generate_rho_semicore.h 21176 2011-10-10 06:35:49Z d3y133 $ */
