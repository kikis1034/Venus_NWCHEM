/*
 $Id: debug.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _DEBUG_H_
#define _DEBUG_H_
/* get_word.h -
   Author - Eric Bylaska

*/

extern int debug_print();
extern void set_debug_print(int i);

#endif
