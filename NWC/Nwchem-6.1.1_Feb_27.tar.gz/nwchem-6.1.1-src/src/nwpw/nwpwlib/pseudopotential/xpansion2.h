#ifndef _GET_CS_H_
#define _GET_CS_H_
/* get_cs.h
*/

extern  void    chi_xpansion2();
extern	void	psi_xpansion2();
extern	void	dpsi_xpansion2();
extern	int	init_xpansion2(int,int,double,
                              double*, double*, double*,
                              double*, double*, double*);

#endif
/* $Id: xpansion2.h 21176 2011-10-10 06:35:49Z d3y133 $ */
