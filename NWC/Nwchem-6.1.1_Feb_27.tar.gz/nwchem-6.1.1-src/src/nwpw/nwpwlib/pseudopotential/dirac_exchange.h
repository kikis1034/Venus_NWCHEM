/*
 $Id: dirac_exchange.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _DIRAC_EXCHANGE_H_
#define _DIRAC_EXCHANGE_H_

extern void   set_Dirac_alpha();
extern double Dirac_alpha();
extern void   R_Dirac_Exchange();
#endif
