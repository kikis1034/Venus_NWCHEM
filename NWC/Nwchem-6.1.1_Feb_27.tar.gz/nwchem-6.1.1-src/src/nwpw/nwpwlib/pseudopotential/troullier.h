/*
 $Id: troullier.h 19707 2010-10-29 17:59:36Z d3y133 $
*/
#ifndef _TROULLIER_H_
#define _TROULLIER_H_
/* troullier.h -
   Author - Eric Bylaska

*/

void	Suggested_Param_Troullier();
void	solve_Troullier();

#endif
