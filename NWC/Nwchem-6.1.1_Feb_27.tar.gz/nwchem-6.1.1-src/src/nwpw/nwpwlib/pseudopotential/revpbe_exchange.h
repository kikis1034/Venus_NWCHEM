#ifndef _revPBE_EXCHANGE_H_
#define _revPBE_EXCHANGE_H_

extern void   R_revPBE_Exchange();
#endif
/* $Id: revpbe_exchange.h 21176 2011-10-10 06:35:49Z d3y133 $ */
