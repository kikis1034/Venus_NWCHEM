#ifndef _PBE_EXCHANGE_H_
#define _PBE_EXCHANGE_H_

extern void   R_PBE96_Exchange();
#endif
/* $Id: pbe_exchange.h 21176 2011-10-10 06:35:49Z d3y133 $ */
