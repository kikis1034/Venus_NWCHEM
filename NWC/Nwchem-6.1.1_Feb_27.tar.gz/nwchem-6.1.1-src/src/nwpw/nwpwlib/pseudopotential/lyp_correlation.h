#ifndef _LYP_H_
#define _LYP_H_

extern void   R_LYP_Correlation();
#endif
/* $Id: lyp_correlation.h 21176 2011-10-10 06:35:49Z d3y133 $ */
