#ifndef _HCURVE_H_
#define _HCURVE_H_
/* hcurve.h -
   Author - Eric Bylaska

*/

extern  void    hcurve_map();

#endif
/* $Id: hcurve.h 21176 2011-10-10 06:35:49Z d3y133 $ */
