#ifndef _hilbert_H_
#define _hilbert_H_
/* hilbert.h -
   Author - Eric Bylaska

*/

extern  void    hilbert2d_map();

#endif
/* $Id: hilbert.h 21176 2011-10-10 06:35:49Z d3y133 $ */
